import React from 'react';
import DropZone from '../DropZone/DropZone';

const Container = ({ id }) => {
  return (
    <DropZone id={id} />
  );
};

export default Container;
